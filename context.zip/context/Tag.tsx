import { useContext } from "react"
import { levelContext } from "./LevelContext"
import { Text } from "react-native"

export const Tag = ({children}) => {
    let value = useContext(levelContext)
    console.log("Tag ",value)
    return (<Text style={{
        fontSize: 18 * value
    }}>
        {children}
    </Text>)
}
import { createContext } from "react";

export  let levelContext = createContext(5)
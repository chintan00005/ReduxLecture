import { View } from "react-native"
import {levelContext} from './LevelContext'
import { useContext } from "react"

export default Section = ({children})=>{
    let value = useContext(levelContext)
    console.log("Section ",value)
    return(
        <levelContext.Provider value={value - 1}>
        {children}
        </levelContext.Provider>)
}
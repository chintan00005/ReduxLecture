import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    headerText: {
        fontSize: 24
    },
    container: {
        flex: 1,
        backgroundColor:"red",
        rowGap:10,
        columnGap:20,
        flexDirection:"row",
        flexWrap:"wrap"
      
    },
    card: {
        flex:1,
    margin:10,
    flexWrap:"wrap",
    justifyContent:"flex-start",
    alignContent:"flex-start"
    },
    card1: {
        backgroundColor: "#Fe9007",
    },
    card2: {
     
        backgroundColor: "#ee8974",
    },
    card3: {
  
        backgroundColor: "#bb7652",
    },
    card4: {
        backgroundColor: "#aa7852",
    },
});
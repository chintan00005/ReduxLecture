import {configureStore, combineReducers} from "@reduxjs/toolkit"
import DataReducer from './reducer'
import {api} from './api'
import {SinglrApiCall} from './SingleApiCall'
import {getErrorMiddleware} from './exampleMiddleWare'

let reducer = combineReducers({
    data:DataReducer
})

export default configureStore({reducer : reducer,
    middleware:(oldMiddlwares)=>[...oldMiddlwares(),api,SinglrApiCall, getErrorMiddleware]
})
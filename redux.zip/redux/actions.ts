import { createAction } from "@reduxjs/toolkit"

// export const ADD_ITEM = "add_item"
// export const REMOVE_ITEM = "remove_item"

// export const addItem = createAction(ADD_ITEM)

// console.log("addItem ",addItem({list:"DATA _ 4"}))

// export const removeItem = createAction(REMOVE_ITEM)

// export const callApi = (index: number)=>{
//     return async (dispatch, initialState)=>{
//             let data = await callApiToServer(index)
//             console.log("CallApi", data)
//             dispatch({ type: ADD_ITEM,
//                 list: data.title})

//     }
// } 


// const callApiToServer= async (id:number)=>{
//   let data = await fetch(`https://jsonplaceholder.typicode.com/todos/${id}`)
//     return data.json()
// }
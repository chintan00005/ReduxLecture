export const getErrorMiddleware = (store:any)=>(next:any)=>(action:any)=>{

    if(action.type=="ERROR")
        {
            console.log("Error Reported")
            next(action)
        }
        else
        {
            next(action)
        }
}
import axios from "axios"

export const SinglrApiCall = (store: any) => (next: any) => (action: any) => {
    if (action.type !== "api_call_single") {
        return next(action)
    }


    let { url, method, onStart, data, onSuccess, onError } = action.payload

    if (onStart) {
        store.dispatch({ type: onStart })
    }
    const callApi = async () => {
        try {
            let reponse = await axios.request({
                baseURL: "http://10.0.2.2:5000/",
                url: "/api/tasks",
                method: method,
                data: data
            })

            store.dispatch({ type: onSuccess, payload: reponse.data })
        } catch (ex) {
            store.dispatch({ type: onError, payload: ex.message })
            store.dispatch({ type: "ERROR" })
        }
    }

    callApi()

}
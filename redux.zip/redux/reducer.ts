import { createReducer, createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import store from './store'
import axios from './http'

let initialArray = {
    loading:false,
    error:null,
    data:["DATA 1", "DATA 2"]
}

// export const fetchTask = createAsyncThunk("fetchTask",async (a,{rejectWithValue})=>{
//     try{
//    let result = await axios.get("abcd")
//    return {task:result.data}
//     }
//     catch(ex)
//     {
//             console.log("Ex ",ex.message)
//             return rejectWithValue({error:ex.message})
//     }
// })

let slice = createSlice({
    name:"task",
    initialState:initialArray,
    reducers:{
        onLoading:(state,action)=>{
            state.loading = true
        },
        onSuccess:(state,action)=>{
            state.loading = false
            console.log("action type ",action.payload)
            state.data = action.payload
        },
        onError:(state,action)=>{
            state.loading=false,
            state.error = action.payload
        },
        callApi:(state,action)=>{
            state.data = action.payload.task
        },
        addItem:(state,action)=>{
            state.data.push(action.payload.list)
        },
        removeItem:(state,action)=>{
            state.data.splice(action.payload.id,1)
        }
    },
    // extraReducers:builder=>{
    //     builder.addCase(fetchTask.pending,(state,action)=>{
    //         state.loading = true
    //     }),
    //     builder.addCase(fetchTask.fulfilled,(state,action)=>{
    //             state.loading = false
    //             state.data = action.payload.task
    //     }),
    //     builder.addCase(fetchTask.rejected,(state,action)=>{
    //         state.loading = false
    //         console.log("Ex action.payload ",action.payload)
    //         state.error = action.payload.error
    //     })
    // }
 
})

export const {addItem, removeItem, callApi, onSuccess, onError, onLoading} = slice.actions
export default slice.reducer

export const callApiAction = createAction("api_call")

export const callSingleApiAction = createAction("api_call_single")

// extraReducers:builder=>{
//     builder.addCase(addItem.type,(state,action)=>{
//         state.push(action.payload.list)
//     }),
//     builder.addCase(action.type,(state,action)=>{
//         state.splice(action.payload.id,1)
//     })
// }
// export default DataReducer = createReducer(["DATA 1", "DATA 2"], builder=>{
//     builder.addCase(addItem.type,(state, action) => {
//         state.push(action.payload.list)
//     }) ,
//     builder.addCase(removeItem.type,(state, action) => {
//         console.log("Action ",action)
//         console.log("State ",state)
//         state.splice(action.payload.id,1)
//     })
    
// }
//)


// export const getDataFromApi = async () =>{
//     console.log("getDataFromApi ")
  
//         try{
//             let response = await axios.get("")
//             console.log("getDataFromApi response ",response)
//             store.dispatch(callApi({task:response.data}))
            
//         }catch(error){
//             console.log("getDataFromApi error ",error)
//             store.dispatch(callApi({task:"Error"}))
//           //  addItem({list:"TEMP"})
//         } 
// }





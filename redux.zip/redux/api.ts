import axios from "axios"
import { onError } from "./reducer"
export const api = (store: any) => (next: any) => (action: any) => {

    if (action.type != "api_call") {
      return  next(action)
    }

    let { url, method, onStart, data, onSuccess, OnError } = action.payload

    if(onStart)
        {
            store.dispatch({type:onStart})
        }

    let apiCall = async () => {
        try {
            let response = await axios.request({
                baseURL: "http://10.0.2.2:5000/",
                url: url,
                method: method,
                data: data
            })

            store.dispatch({type:onSuccess, payload : response.data})
        }
        catch (ex) {
            console.log("OnError ",onError.type)
            store.dispatch({type:OnError, payload:ex.message})
            store.dispatch({type:"ERROR"})
        }
    }

    apiCall()

}
import { Button, Text, View } from "react-native"
import {getCustomValue} from './CustomFunction'

export const CustomElement = () =>{
    const {add,minus , counter} = getCustomValue(0)
    return(
        <View>
            <Text>{counter}</Text>
        <Button
            title="Add"
            onPress={()=>{add()}}
        />
        <Button
        title="Remove"
        onPress={()=>{minus()}}
    />
    </View>
    )
}
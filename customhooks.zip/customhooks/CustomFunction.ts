import { useEffect, useState } from "react"

export const getCustomValue = (initialValue) => {
    const [counter, setCounter] = useState(initialValue)
    const [add, setAdd] = useState(() => { })
    const [minus, setMinus] = useState(() => { })


    // const setData = async () => {
    //     setAdd(() => { setCounter(counter + 1) })
    //     setMinus(() => { setCounter(counter + 1) })
    // }

    useEffect(() => {
        console.log("initialValue 1 ",initialValue)
        console.log("counter 1 ",counter)
        console.log("Add 1 ",add)
        // setAdd(() => { setCounter(counter + 1) })
        // console.log("Add 2 ",add)
    }, [])


    return { add, minus, counter }
}
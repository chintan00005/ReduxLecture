import { Button, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { addItem, removeItem } from '../redux/reducer'

export default function ListItem({item,dispatch,length} : any) {
  return (
    <View style={styles.container}>
    <View style={styles.verticalContainer}>
      <Text>{item.item.task}</Text>
      <Text>Subtitle</Text>
    </View>
    <Button
    title='Add Item'
    onPress={()=>{dispatch(addItem({list:`Data ${length+1}`}))}}
    />
        <Button
    title='Remove Item'
    onPress={()=>{dispatch(removeItem({id:0}))}}
    />
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        flexDirection:"row",
        padding:10,
        alignItems:"center",
        justifyContent:"space-between"
    },
    verticalContainer:{
      flex:4
    },
    textStyle:{
      flex:1
    }
})
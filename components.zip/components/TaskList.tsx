import { Button, FlatList, StyleSheet, Text, View } from 'react-native'
import React,{useState} from 'react'
import ListItem from './ListItem'
import { useRoute } from '@react-navigation/native'
import { UseSelector, useDispatch, useSelector } from 'react-redux'
import {addItem,callApiAction,callSingleApiAction,fetchTask,onError,onLoading,onSuccess,removeItem} from '../redux/reducer'


export default function TaskList() {
  const dispatch = useDispatch()
  let list =  useSelector((state)=>{
    console.log("useSelector ",state.data)
    return state.data.data})
  return (
    <View style={{ flex: 1 }}>

    {/* <FlatList  
      data={list}
      renderItem={(item) => <ListItem item={item} dispatch={dispatch} length = {list.length}/>}
      keyExtractor={item => item.id}
    /> */}
    <Text>{list.task?list.task:list}</Text>
     {/* onPress={()=>{dispatch(addItem({list:`Data ${3}`}))}} */}
    <Button
    title='Add Item'
   
    onPress={()=>{
      dispatch(callSingleApiAction(postRequest()))}}
    />
        <Button
    title='Remove Item'
    onPress={()=>{dispatch({type:"ERROR"})}}
    />
  </View>
  )
  function getRequest(){
    return {
        url:"api/tasks",
        method:"GET",
        onStart:onLoading.type,
        onSuccess:onSuccess.type,
        OnError:onError.type
    }
  }

  function postRequest(){
    return {
        url:"api/tasks",
        method:"post",
        data:{task:"this is added"},
        onStart:onLoading.type,
        onSuccess:onSuccess.type,
        OnError:onError.type
    }
  }
}


